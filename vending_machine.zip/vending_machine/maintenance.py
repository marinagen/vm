from stored_data import products, REMAINING_QUANTITY, coins_remain, Q, N


def maintenance_vm(num_accepted, coins_remain):
    number = 0
    for i in range(len(products)):
        products[i][REMAINING_QUANTITY] = Q
    for k in range(len(coins_remain)):
        coins_remain[k] = N
    for j in range(len(num_accepted)):
        number += num_accepted[j]
    print(f'The number of each denomination:{num_accepted}; '
          f'Number of banknotes: {number}')
    num_accepted = [0, 0, 0, 0]
    print('Press a key')
    #return coins_remain
