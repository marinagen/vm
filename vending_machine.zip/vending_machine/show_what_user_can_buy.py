from stored_data import products, PRICE, REMAINING_QUANTITY, coins_remain, coins_available


def select_products(credit):
    can_buy = []
    for i in range(len(products)):
        if products[i][PRICE] <= credit and products[i][REMAINING_QUANTITY] > 0:
            can_buy.append(products[i])
    if len(can_buy) > 0:
        print(can_buy)
        j = int(input('Enter the number of selected product: '))
        if products[j-1] in can_buy:
            sum = 0
            for i in range(len(coins_remain)):
                sum += coins_remain[i] * coins_available[i]
            if sum < credit - products[j-1][PRICE]:
                print('No change for this product')
            else:
                products[j-1][REMAINING_QUANTITY] -= 1
                credit -= products[j - 1][PRICE]
                print(products[j - 1])
                return credit
        else:
            print(f"You can't buy {j} product")
    else:
        print('No products available')
        return credit
