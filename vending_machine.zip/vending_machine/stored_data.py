NUMBER = 0
NAME = 1
PRICE = 2
REMAINING_QUANTITY = 3
Q = 15  # quantity of product
products = [
    [1, 'Snickers', 55, Q],
    [2, 'Mars', 45, Q],
    [3, 'Oreo', 60, Q],
    [4, 'Obukhovskaya', 30, Q],
    [5, 'Skittles', 40, Q],
    [6, 'Lays', 70, Q],
    [7, 'Coca-Cola', 35, Q],
    [8, '3 Korochki', 20, Q],
    [9, 'M&Ms', 50, Q],
    [10, 'Milka', 60, Q],
    [11, 'Sprite', 40, Q],
    [12, 'Sandwich', 100, Q],
    [13, 'Lipton', 45, Q],
    [14, 'Bounty', 50, Q],
    [15, 'Bon Aqua', 60, Q]
]
QUANTITY_RUB500 = 0
QUANTITY_RUB200 = 1
QUANTITY_RUB100 = 2
QUANTITY_RUB50 = 3
RUB500 = 500
RUB200 = 200
RUB100 = 100
RUB50 = 50
accepted_cash = [0, 0, 0, 0]
denominations_available = [RUB500, RUB200, RUB100, RUB50]
QUANTITY_RUB10 = 0
QUANTITY_RUB5 = 1
QUANTITY_RUB2 = 2
QUANTITY_RUB1 = 3
RUB10 = 10
RUB5 = 5
RUB2 = 2
RUB1 = 1
N = 10  # Coins remain
coins_remain = [5, 0, 0, 0]
coins_available = [RUB10, RUB5, RUB2, RUB1]
