from stored_data import coins_remain
from is_service_needed import is_service_needed
from maintenance import maintenance_vm
from insert import insert_banknote
from show_available_products import available_products
from show_what_user_can_buy import select_products
from advanced_func import change
num_accepted = [0, 0, 0, 0]
credit = 0
service_needed = 0
options = [[1, 'insert a banknote'],
           [2, 'show available products'],
           [3, 'select a product'],
           [4, 'get a change']]
while True:
    if service_needed == 1:
        choice = input('Enter the secret password: ')
        if choice == 'srvop17':
            maintenance_vm(num_accepted, coins_remain)
            service_needed = 0
    else:
        print(options)
        choice = (input('Choose a number of option: '))
        try:
            choice = int(choice)
            if choice in [1, 2, 3, 4]:
                if choice == 1:
                    num_accepted, summa = insert_banknote()
                    credit += summa
                    print(f'Denominations entered: {num_accepted};'
                          f' Accepted sum: {credit}')
                elif choice == 2:
                    available_products()
                elif choice == 3:
                    credit = select_products(credit)
                elif choice == 4:
                    credit = change(credit)
                    service_needed = is_service_needed()
            else:
                print('No such option')
        except:
            print('Wrong input')
