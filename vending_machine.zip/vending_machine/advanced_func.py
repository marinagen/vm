from stored_data import coins_remain, coins_available
num = []


def change(credit):
    sum = 0
    for i in range(len(coins_remain)):
        sum += coins_remain[i] * coins_available[i]
    if sum < credit:
        print('No change for this sum')
        return credit
    else:
        for i in range(len(coins_available)):
            if credit // coins_available[i] > coins_remain[i]:
                credit -= coins_remain[i] * coins_available[i]
                num.append(coins_remain[i])
                coins_remain[i] = 0
            else:
                num.append(credit // coins_available[i])
                coins_remain[i] -= num[i]
                credit %= coins_available[i]
        print(f'Number of RUB10 = {num[0]}, RUB5 = {num[1]}, RUB2 = {num[2]}, RUB1 = {num[3]}')
        return credit
