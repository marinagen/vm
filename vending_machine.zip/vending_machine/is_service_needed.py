from stored_data import products, REMAINING_QUANTITY, coins_remain


def is_service_needed():
    summa = 0
    service_needed = 0
    for i in range(len(products)):
        if products[i][REMAINING_QUANTITY] == 0:
            summa += 1
        if summa == len(products):
            service_needed = 1
            print('Service is needed')
    for j in range(len(coins_remain)):
        if coins_remain[j] == 0:
            summa += 1
        if summa == len(coins_remain):
            service_needed = 1
            print('Service is needed')
    return service_needed
