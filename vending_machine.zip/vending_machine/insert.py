from stored_data import denominations_available, accepted_cash


def insert_banknote():
    summa = 0
    try:
        denomination = int(input('Insert a banknote: '))
        if denomination in denominations_available:
            pos = denominations_available.index(denomination)
            accepted_cash[pos] += 1
            summa += denomination
            return accepted_cash, summa
        print('This banknote is not supported')
    except:
        print('Wrong input, please insert a banknote')
