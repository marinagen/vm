from stored_data import products, REMAINING_QUANTITY, NAME


def available_products():
    show = []
    for i in range(0, len(products)):
        if products[i][REMAINING_QUANTITY] > 0:
            show.append(products[i][NAME])
    print(f'Available products: {show}')
